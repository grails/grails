class BlogGrailsPlugin {
	def dependsOn = ['fckeditor':'0.8 > *']
    def version = 0.1

    def author = "Graeme Rocher"
    def authorEmail = "graeme@g2one.com"
    def title = "A blogging plugin"
    def description = 'A plugin that provides a blog facility to the gTunes application'
}
