class TestPluginController {

	def index = {
		render "test-plugin installed successfully!"
	}

}