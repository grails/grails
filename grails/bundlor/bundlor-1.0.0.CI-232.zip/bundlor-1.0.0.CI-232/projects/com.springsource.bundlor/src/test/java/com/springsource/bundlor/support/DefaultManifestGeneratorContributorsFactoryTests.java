/*
 * Copyright 2009 SpringSource
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.springsource.bundlor.support;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.util.List;
import java.util.Properties;

import org.junit.Test;

import com.springsource.bundlor.support.asm.AsmTypeArtefactAnalyser;
import com.springsource.bundlor.support.contributors.BlueprintArtifactAnalyzer;
import com.springsource.bundlor.support.contributors.BundleClassPathArtifactAnalyzer;
import com.springsource.bundlor.support.contributors.ExcludedImportAndExportPartialManifestModifier;
import com.springsource.bundlor.support.contributors.HibernateMappingArtefactAnalyser;
import com.springsource.bundlor.support.contributors.IgnoredExistingHeadersManifestModifier;
import com.springsource.bundlor.support.contributors.JpaPersistenceArtefactAnalyser;
import com.springsource.bundlor.support.contributors.JspArtifactAnalyzer;
import com.springsource.bundlor.support.contributors.Log4JXmlArtifactAnalyzer;
import com.springsource.bundlor.support.contributors.ManifestTemplateDirectiveMigrator;
import com.springsource.bundlor.support.contributors.OsgiProfileManifestTemplateModifier;
import com.springsource.bundlor.support.contributors.SpringApplicationContextArtefactAnalyser;
import com.springsource.bundlor.support.contributors.StaticResourceArtefactAnalyser;
import com.springsource.bundlor.support.contributors.ToolStampManifestModifier;
import com.springsource.bundlor.support.contributors.WebApplicationArtifactAnalyzer;
import com.springsource.bundlor.support.partialmanifest.StandardPartialManifestResolver;
import com.springsource.bundlor.support.partialmanifest.StandardReadablePartialManifest;
import com.springsource.bundlor.support.properties.PropertiesSource;
import com.springsource.bundlor.support.propertysubstitution.PlaceholderManifestAndTemplateModifier;

public class DefaultManifestGeneratorContributorsFactoryTests {

    private final ManifestGeneratorContributors contributors = DefaultManifestGeneratorContributorsFactory.create(new StubPropertiesSource(
        Integer.MAX_VALUE), new StubPropertiesSource(Integer.MIN_VALUE));

    @Test
    public void artifactAnalyzers() {
        assertContainsInstanceOf(contributors.getArtifactAnalyzers(), //
            AsmTypeArtefactAnalyser.class, //
            StaticResourceArtefactAnalyser.class, //
            HibernateMappingArtefactAnalyser.class, //
            JpaPersistenceArtefactAnalyser.class, //
            Log4JXmlArtifactAnalyzer.class, //
            SpringApplicationContextArtefactAnalyser.class, //
            BlueprintArtifactAnalyzer.class, //
            WebApplicationArtifactAnalyzer.class, //
            BundleClassPathArtifactAnalyzer.class, //
            JspArtifactAnalyzer.class);
    }

    @Test
    public void manifestReaders() {
        assertContainsInstanceOf(contributors.getManifestReaders(), //
            ExcludedImportAndExportPartialManifestModifier.class, //
            IgnoredExistingHeadersManifestModifier.class, //
            BlueprintArtifactAnalyzer.class, //
            ManifestTemplateDirectiveMigrator.class);
    }

    @Test
    public void manifestModifiers() {
        assertContainsInstanceOf(contributors.getManifestModifiers(), //
            PlaceholderManifestAndTemplateModifier.class, //
            IgnoredExistingHeadersManifestModifier.class, //
            ToolStampManifestModifier.class);
    }

    @Test
    public void manifestTemplateModifiers() {
        assertContainsInstanceOf(contributors.getManifestTemplateModifiers(), //
            ManifestTemplateDirectiveMigrator.class, //
            PlaceholderManifestAndTemplateModifier.class, //
            OsgiProfileManifestTemplateModifier.class);
    }

    @Test
    public void partialManifestModifiers() {
        assertContainsInstanceOf(contributors.getPartialManifestModifiers(), //
            ManifestTemplateDirectiveMigrator.class, //
            ExcludedImportAndExportPartialManifestModifier.class);
    }

    @Test
    public void manifestContributors() {
        assertContainsInstanceOf(contributors.getManifestContributors(), //
            BundleClassPathArtifactAnalyzer.class);
    }

    @Test
    public void templateHeaderReaders() {
        assertContainsInstanceOf(contributors.getTemplateHeaderReaders(), //
            ExcludedImportAndExportPartialManifestModifier.class, //
            IgnoredExistingHeadersManifestModifier.class, // 
            PlaceholderManifestAndTemplateModifier.class, //
            StandardPartialManifestResolver.class);
    }

    @Test
    public void entryScannerListeners() {
        assertContainsInstanceOf(contributors.getEntryScannerListeners() //
        );
    }

    @Test
    public void readablePartialManifest() {
        assertTrue(contributors.getReadablePartialManifest() instanceof StandardReadablePartialManifest);
    }

    @Test
    public void partialManifestResolver() {
        assertTrue(contributors.getPartialManifestResolver() instanceof StandardPartialManifestResolver);
    }

    private final <T> void assertContainsInstanceOf(List<T> candidates, Class<?>... clazzes) {
        assertEquals(candidates.size(), clazzes.length);
        for (Class<?> clazz : clazzes) {
            for (T candidate : candidates) {
                if (candidate.getClass().equals(clazz)) {
                    return;
                }
            }
            fail(String.format("Default contributors does not contain an instance of '%s'", clazz.getName()));
        }
    }

    private static class StubPropertiesSource implements PropertiesSource {

        private final int priority;

        public StubPropertiesSource(int priority) {
            this.priority = priority;
        }

        public int getPriority() {
            return this.priority;
        }

        public Properties getProperties() {
            return new Properties();
        }

    }
}
