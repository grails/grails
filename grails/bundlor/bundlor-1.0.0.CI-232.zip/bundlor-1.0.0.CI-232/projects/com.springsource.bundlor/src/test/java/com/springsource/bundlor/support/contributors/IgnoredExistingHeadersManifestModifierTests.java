/*
 * Copyright 2008-2009 SpringSource
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.springsource.bundlor.support.contributors;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.util.List;

import org.junit.Test;

import com.springsource.bundlor.util.SimpleManifestContents;
import com.springsource.util.parser.manifest.ManifestContents;

public class IgnoredExistingHeadersManifestModifierTests {

    private IgnoredExistingHeadersManifestModifier modifier = new IgnoredExistingHeadersManifestModifier();

    @Test
    public void excludedExistingHeaders() {
        ManifestContents manifestTemplate = new SimpleManifestContents();
        manifestTemplate.getMainAttributes().put("Ignored-Existing-Headers", "Import-Package,Export-Package");
        modifier.readManifestTemplate(manifestTemplate);

        ManifestContents artefact = new SimpleManifestContents();
        artefact.getMainAttributes().put("Import-Package", "com.ridiculous.import");
        artefact.getMainAttributes().put("Export-Package", "com.ridiculous.export");

        modifier.modify(artefact);
        assertNull(artefact.getMainAttributes().get("Import-Package"));
        assertNull(artefact.getMainAttributes().get("Export-Package"));
    }

    @Test
    public void names() {
        List<String> names = this.modifier.getTemplateOnlyHeaderNames();
        assertEquals(1, names.size());
        assertTrue(names.contains("Ignored-Existing-Headers"));
    }

    @Test
    public void wildcardExcludedExistingHeaders() {
        ManifestContents manifestTemplate = new SimpleManifestContents();
        manifestTemplate.getMainAttributes().put("Ignored-Existing-Headers", "Alpha-*,*-Bravo,Charlie-*-Delta,*-Echo-*");
        modifier.readManifestTemplate(manifestTemplate);

        ManifestContents artefact = new SimpleManifestContents();
        artefact.getMainAttributes().put("Alpha-Test", "com.ridiculous.import");
        artefact.getMainAttributes().put("Test-Bravo", "com.ridiculous.export");
        artefact.getMainAttributes().put("Charlie-Test-Delta", "com.ridiculous.export");
        artefact.getMainAttributes().put("Test-Echo-Test", "com.ridiculous.export");
        artefact.getMainAttributes().put("Import-Package", "com.ridiculous.export");

        modifier.modify(artefact);
        assertNull(artefact.getMainAttributes().get("Alpha-Test"));
        assertNull(artefact.getMainAttributes().get("Test-Bravo"));
        assertNull(artefact.getMainAttributes().get("Charlie-Test-Delta"));
        assertNull(artefact.getMainAttributes().get("Test-Echo-Test"));
        assertNotNull(artefact.getMainAttributes().get("Import-Package"));        
    }
}
