/*
 * Copyright 2008-2009 SpringSource
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.springsource.bundlor.support.contributors;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Set;

import org.junit.Test;

import com.springsource.bundlor.support.partialmanifest.ReadablePartialManifest;
import com.springsource.bundlor.support.partialmanifest.StandardReadablePartialManifest;

public class JpaPersistenceArtefactAnalyserTests {

    private static final String artifactName = "src/test/resources/com/springsource/bundlor/support/contributors/persistence.xml";

    private final JpaPersistenceArtefactAnalyser analyzer = new JpaPersistenceArtefactAnalyser();

    @Test
    public void testCanAnalyze() {
        assertTrue(analyzer.canAnalyse("META-INF/persistence.xml"));
        assertFalse(analyzer.canAnalyse(artifactName));
    }

    @Test
    public void testJpaPersistence() throws Exception {
        ReadablePartialManifest partialManifest = new StandardReadablePartialManifest();
        InputStream artifact = new FileInputStream(artifactName);

        analyzer.analyse(artifact, artifactName, partialManifest);
        Set<String> imports = partialManifest.getImportedPackages();

        assertTrue(imports.contains("com.springsource.provider"));
        assertTrue(imports.contains("com.springsource.class1"));
        assertTrue(imports.contains("com.springsource.class2"));
    }
}
