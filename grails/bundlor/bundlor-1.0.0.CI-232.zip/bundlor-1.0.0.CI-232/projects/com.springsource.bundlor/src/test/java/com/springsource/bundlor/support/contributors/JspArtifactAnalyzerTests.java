/*
 * Copyright 2009 SpringSource
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.springsource.bundlor.support.contributors;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.io.ByteArrayInputStream;
import java.util.Set;

import org.junit.Test;

import com.springsource.bundlor.support.partialmanifest.ReadablePartialManifest;
import com.springsource.bundlor.support.partialmanifest.StandardReadablePartialManifest;

public class JspArtifactAnalyzerTests {

    private final JspArtifactAnalyzer analyzer = new JspArtifactAnalyzer();

    @Test
    public void isolated() throws Exception {
        ReadablePartialManifest partialManifest = new StandardReadablePartialManifest();
        ByteArrayInputStream in = new ByteArrayInputStream(
            "<%@ page import=\"com.springsource.test.foo.class, com.springsource.test.bar.*\" %>".getBytes());
        this.analyzer.analyse(in, "test.jsp", partialManifest);

        Set<String> importedPackages = partialManifest.getImportedPackages();
        assertTrue(importedPackages.contains("com.springsource.test"));
        assertTrue(importedPackages.contains("com.springsource.test.bar"));
    }

    @Test
    public void beginning() throws Exception {
        ReadablePartialManifest partialManifest = new StandardReadablePartialManifest();
        ByteArrayInputStream in = new ByteArrayInputStream(
            "<%@ page import=\"com.springsource.test.foo.class, com.springsource.test.bar.*\" buffer=\"5kb\" autoFlush=\"false\" %> ".getBytes());
        this.analyzer.analyse(in, "test.jsp", partialManifest);

        Set<String> importedPackages = partialManifest.getImportedPackages();
        assertTrue(importedPackages.contains("com.springsource.test"));
        assertTrue(importedPackages.contains("com.springsource.test.bar"));
    }

    @Test
    public void end() throws Exception {
        ReadablePartialManifest partialManifest = new StandardReadablePartialManifest();
        ByteArrayInputStream in = new ByteArrayInputStream(
            "<%@ page errorPage=\"error.jsp\" import=\"com.springsource.test.foo.class, com.springsource.test.bar.*\" %>".getBytes());
        this.analyzer.analyse(in, "test.jsp", partialManifest);

        Set<String> importedPackages = partialManifest.getImportedPackages();
        assertTrue(importedPackages.contains("com.springsource.test"));
        assertTrue(importedPackages.contains("com.springsource.test.bar"));
    }

    @Test
    public void canAnalyze() {
        assertTrue(this.analyzer.canAnalyse("WEB-INF/jsp/index.jsp"));
        assertFalse(this.analyzer.canAnalyse("WEB-INF/jsp/index.html"));
    }
}
