/*
 * Copyright 2009 SpringSource
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.springsource.bundlor.support.contributors;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.util.Set;

import org.junit.Test;
import org.osgi.framework.Constants;

import com.springsource.bundlor.support.partialmanifest.StandardReadablePartialManifest;
import com.springsource.bundlor.util.SimpleManifestContents;

public class ManifestTemplateDirectiveMigratorTests {

    private final ManifestTemplateDirectiveMigrator contributor = new ManifestTemplateDirectiveMigrator();

    @Test
    public void importPackage() {
        SimpleManifestContents template = new SimpleManifestContents();
        template.getMainAttributes().put(Constants.IMPORT_PACKAGE,
            "com.springsource.test;version=0,com.springsource.test2;version=1;resolution:=optional");
        this.contributor.readManifestTemplate(template);

        StandardReadablePartialManifest partialManifest = new StandardReadablePartialManifest();
        this.contributor.modify(partialManifest);

        Set<String> importedPackages = partialManifest.getImportedPackages();
        assertEquals(2, importedPackages.size());
        assertTrue(importedPackages.contains("com.springsource.test"));
        assertTrue(importedPackages.contains("com.springsource.test2"));
    }

    @Test
    public void importPackageNull() {
        SimpleManifestContents template = new SimpleManifestContents();
        this.contributor.readManifestTemplate(template);

        StandardReadablePartialManifest partialManifest = new StandardReadablePartialManifest();
        this.contributor.modify(partialManifest);

        Set<String> importedPackages = partialManifest.getImportedPackages();
        assertEquals(0, importedPackages.size());
    }

    @Test
    public void exportPackage() {
        SimpleManifestContents template = new SimpleManifestContents();
        template.getMainAttributes().put(Constants.EXPORT_PACKAGE, "com.springsource.test;version=0,com.springsource.test2;version=1");
        this.contributor.readManifestTemplate(template);

        StandardReadablePartialManifest partialManifest = new StandardReadablePartialManifest();
        this.contributor.modify(partialManifest);

        Set<String> exportedPackages = partialManifest.getExportedPackages();
        assertEquals(2, exportedPackages.size());
        assertTrue(exportedPackages.contains("com.springsource.test"));
        assertTrue(exportedPackages.contains("com.springsource.test2"));
    }

    @Test
    public void exportPackageNull() {
        SimpleManifestContents template = new SimpleManifestContents();
        this.contributor.readManifestTemplate(template);

        StandardReadablePartialManifest partialManifest = new StandardReadablePartialManifest();
        this.contributor.modify(partialManifest);

        Set<String> exportedPackages = partialManifest.getExportedPackages();
        assertEquals(0, exportedPackages.size());
    }

    @Test
    public void importTemplate() {
        SimpleManifestContents template = new SimpleManifestContents();
        template.getMainAttributes().put(Constants.IMPORT_PACKAGE,
            "com.springsource.test;version=0,com.springsource.test2;version=1;resolution:=optional");
        this.contributor.readManifestTemplate(template);
        this.contributor.modify(template);

        String importTemplateString = template.getMainAttributes().get("Import-Template");
        assertNotNull(importTemplateString);
        assertEquals("com.springsource.test;version=0,com.springsource.test2;version=1;resolution:=optional", importTemplateString);
    }

    @Test
    public void importTemplateAdditional() {
        SimpleManifestContents template = new SimpleManifestContents();
        template.getMainAttributes().put("Import-Template", "com.springsource.test3;version=0");
        template.getMainAttributes().put(Constants.IMPORT_PACKAGE,
            "com.springsource.test;version=0,com.springsource.test2;version=1;resolution:=optional");
        this.contributor.readManifestTemplate(template);
        this.contributor.modify(template);

        String importTemplateString = template.getMainAttributes().get("Import-Template");
        assertNotNull(importTemplateString);
        assertEquals("com.springsource.test3;version=0,com.springsource.test;version=0,com.springsource.test2;version=1;resolution:=optional",
            importTemplateString);
    }

    @Test
    public void exportTemplate() {
        SimpleManifestContents template = new SimpleManifestContents();
        template.getMainAttributes().put(Constants.EXPORT_PACKAGE, "com.springsource.test;version=0,com.springsource.test2;version=1");
        this.contributor.readManifestTemplate(template);
        this.contributor.modify(template);

        String exportTemplateString = template.getMainAttributes().get("Export-Template");
        assertNotNull(exportTemplateString);
        assertEquals("com.springsource.test;version=0,com.springsource.test2;version=1", exportTemplateString);
    }

    @Test
    public void exportTemplateAdditional() {
        SimpleManifestContents template = new SimpleManifestContents();
        template.getMainAttributes().put("Export-Template", "com.springsource.test3;version=0");
        template.getMainAttributes().put(Constants.EXPORT_PACKAGE, "com.springsource.test;version=0,com.springsource.test2;version=1");
        this.contributor.readManifestTemplate(template);
        this.contributor.modify(template);

        String exportTemplateString = template.getMainAttributes().get("Export-Template");
        assertNotNull(exportTemplateString);
        assertEquals("com.springsource.test3;version=0,com.springsource.test;version=0,com.springsource.test2;version=1", exportTemplateString);
    }
}
